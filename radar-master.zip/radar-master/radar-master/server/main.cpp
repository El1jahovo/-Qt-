#include "widget.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Widget server;
    server.show(); // 虽然不需要UI，但需要保持程序运行

    return a.exec();
}
