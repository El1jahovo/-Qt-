#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include <QTimer>
#include <QColor>
#include <QJsonObject>
#include <QHostAddress>  // 必须包含 QHostAddress 的头文件

class QLabel;
class QTextEdit;
class QSpinBox;
class QDoubleSpinBox;
class QPushButton;
class QLineEdit;
class QCheckBox;
class QGroupBox;

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void connectToServer();
    void disconnectFromServer();
    void readData();
    void sendManualPoint();
    void startAutoSending();
    void stopAutoSending();
    void generateRandomPoint();
    void selectColor();
    void toggleRandomColor(int state);
    void connectionStateChanged(QAbstractSocket::SocketState state);

private:
    void setupUI();
    void sendPointData(const QJsonObject &pointData);
    void displayPointData(const QJsonObject &pointData);
    QString convertDirection(double degrees);
    void updateColorButton();

    // UI components
    QLabel *statusLabel;
    QTextEdit *textEdit;
    QLineEdit *serverIpLineEdit;
    QSpinBox *serverPortSpinBox;
    QPushButton *connectButton;
    QPushButton *disconnectButton;
    QDoubleSpinBox *manualXSpinBox;
    QDoubleSpinBox *manualYSpinBox;
    QDoubleSpinBox *manualDirectionSpinBox;
    QDoubleSpinBox *manualSpeedSpinBox;
    QPushButton *manualSendButton;
    QSpinBox *autoSendIntervalSpinBox;
    QPushButton *startAutoSendButton;
    QPushButton *stopAutoSendButton;
    QCheckBox *randomColorCheckBox;
    QPushButton *selectColorButton;

    // Network
    QTcpSocket *tcpSocket;
    QTimer *autoSendTimer;

    // Data
    QColor pointColor;
};

#endif // WIDGET_H
