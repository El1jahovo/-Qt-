#ifndef WIDGET_H
#define WIDGET_H

#include "radar.h"
#include "connect.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QVBoxLayout>
#include <QWidget>
#include <QFont>
#include <QScrollArea>
#include <QComboBox>
#include <QPushButton>
#include <QConicalGradient>

#include <QtNetwork/QTcpServer>

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    QWidget * createLeftPanel();    // 创建左边面板
    QWidget * createRightPanel();   // 创建右边面板
    QWidget * createStationInfoWidget();    // 创建目标点信息
    QWidget * createWeaponControlPanel();    // 创建武器控制
    QWidget * createScrollingInfoList();     // 创建信息滚动


    void startScrollTimer();        // 启动滚动
    QVBoxLayout *scrollLayout = nullptr;    // 滚动布局
    QScrollArea *scrollArea = nullptr;      // 滚动区域
    QTimer *scrollTimer = nullptr;          // 滚动计时器

    void refreshScrollList(); // 刷新滚动列表
    void setImLabelText(const QString &text);  // 新增设置标签文本的方法
    QMap<long, Target> &getmap(){return radarDataMap;}

    double calculateRelativeDistanceQt(const QPointF &m_center, double m_radius, const QPointF &newPoint);
    QString convertDirection(qreal angleRadian);

    QString targetToDisplayString(const Target &target);


public slots:
    void closeEvent(QCloseEvent *event);
    void on_con_btn_clicked();
    void on_close_btn_clicked();
    void deletePointInMap();

    void updateRadarData(Target &point); // 更新滚动列表数据
    void updatePointData(long id, Target &point);

private:

    QHBoxLayout *mainLayout;    // 主体布局
    QWidget *leftPanel;         // 左边面板窗口
    QVBoxLayout *leftLayout;    // 左边面板垂直分布
    QWidget *rightPanel;        // 右边面板窗口
    QVBoxLayout *rightLayout;   // 右边面板垂直分布
    QWidget *leftWidget;        // 左边窗口

    // 基站
    QWidget *stationInfo;       // 基站信息
    QWidget *stationInfoWidget; // 基站信息窗口
    QHBoxLayout *stationInfoLayout; // 基站信息窗口布局
    QVBoxLayout *infoLayout;    // 基站信息块布局
    QHBoxLayout *stationName;        // 基站站点信息
    QLabel *stationLabel;       // 基站标签
    QComboBox *stationCombo;    // 基站连接端口
    QLabel *status;             // 基站状态
    QLabel *personnel;          // 基站人员数量
    QHBoxLayout *btnLayout;     // 按键布局
    QPushButton *con_btn;       // 连接按钮
    QPushButton *close_btn;     // 断开连接按钮

    // 武器栏
    QWidget *weaponPanel;       // 武器栏窗口
    QVBoxLayout *weaponlayout;  // 武器栏窗口布局
    QHBoxLayout *row1;          // 武器选择栏布局
    QLabel *weaponLabel;        // 武器标签栏
    QComboBox *weaponCombo;     // 武器下拉标签
    QPushButton *fireBtn;       // 发射按钮
    QLabel *ImLable;            // 选中目标点的信息栏


    QTimer *scanTimer;          // 定时器
    Ui::Widget *ui;

    // Network
    QTcpServer *tcpServer;
    QTcpSocket *currentConnection;


    QWidget *scrollContent;

    QTimer *m_updateTimer;
    Radar *radar;
    int m_scanAngle = 0;

    Connect *cnt;   // 新窗口

    QMap<long, Target> radarDataMap; // 接收到的数据点map

};
#endif // WIDGET_H
