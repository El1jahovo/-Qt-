#ifndef CONNECT_H
#define CONNECT_H

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QTextEdit>
#include <QSpinBox>
#include <QPushButton>
#include <QJsonDocument>
#include <QDateTime>
#include <cmath>
#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QJsonObject>
#include "target.h"

namespace Ui {
class Connect;
}

class Connect : public QWidget
{
    Q_OBJECT

public:
    explicit Connect(QWidget *parent = nullptr);
    ~Connect();

    void startListening();
    void stopListening();
    void displayPointData(const QJsonObject &pointData);
    QString convertDirection(double degrees);
    void readData();
    void disconnected();
    void newConnection();

    Target parseTargetFromJson(const QJsonObject& obj, long id); // 解析数据为Target
private:
    Ui::Connect *ui;
    void setupUI();

    // UI components
    QLabel *statusLabel;
    QTextEdit *textEdit;
    QSpinBox *listenPortSpinBox;
    QPushButton *startButton;
    QPushButton *stopButton;

    // Network
    QTcpServer *tcpServer;
    QTcpSocket *currentConnection;

    long pointId = 0;

signals:
    void pointDataReceived(Target &point);  // 发送目标信息给界面更新

};

#endif // CONNECT_H
