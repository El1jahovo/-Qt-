#include "target.h"

#include <QtMath>

Target::Target() : id(0), relDistance(0.0), angle(0.0), speed(0.0), color(Qt::red)
{
}

QPointF Target::currentPosition() const
{
    // 将相对距离与角度转换为平面坐标，假设最大半径为1，之后再映射到画布尺寸
    qreal x = relDistance * qCos(angle);
    qreal y = relDistance * qSin(angle);
    return QPointF(x, y);
}

