#ifndef RADAR_H
#define RADAR_H

#include <QPaintEvent>
#include <QPainter>
#include <QTimer>
#include <QWidget>
#include "target.h"

class Widget;

class Radar : public QWidget
{
    Q_OBJECT
public:
    explicit Radar(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *event);
    void drawBackground(QPainter &painter);
    void drawGrid(QPainter &painter);
    void drawScanLine(QPainter &painter);
    void updateScanAngle(int angle);
    void initTargets();
    void updateTargets();
    void drawTargets(QPainter &painter);
    int getradius(){ return m_radius;}
    QPoint getcenter(){return m_center;}
    long  getid(){return id;}

    QPointF calculatePosition(qreal relDistance, qreal angle) const;
public slots:
    void mousePressEvent(QMouseEvent *event);
signals:
    void updatePointData(long id, Target &point);  // 发送目标信息给界面更新

private:

    QTimer *m_updateTimer;
    int m_scanAngle = 0;
    QPoint m_center;
    int m_radius;
    int scanAngle;
    Widget *wgt;

    long id;

    QVector<Target> m_targets;
    const int MAX_HISTORY = 10; // 历史轨迹点数
};

#endif // RADAR_H
