#ifndef TARGET_H
#define TARGET_H

#include <QColor>
#include <QVector>
#include <QPointF>

class Target
{
public:
    Target();

    long id;                  // 目标点 ID
    double relDistance;        // 相对距离 (0.0 - 1.0)
    qreal x, y;
    qreal angle;              // 当前角度（弧度）
    qreal speed;              // 移动速度
    QColor color;             // 目标颜色
    QVector<Target> history; // 历史轨迹

    QPointF currentPosition() const; // 当前绝对坐标
};


#endif // TARGET_H
